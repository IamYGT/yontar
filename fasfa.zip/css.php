	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo $ayarlar["strURL"]; ?>/assets/vendors/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $ayarlar["strURL"]; ?>/assets/vendors/animate/animate.min.css">
    <link rel="stylesheet" href="<?php echo $ayarlar["strURL"]; ?>/assets/vendors/animate/custom-animate.css">
    <link rel="stylesheet" href="<?php echo $ayarlar["strURL"]; ?>/assets/vendors/fontawesome/css/all.min.css">
    <link rel="stylesheet" href="<?php echo $ayarlar["strURL"]; ?>/assets/vendors/jarallax/jarallax.css">
    <link rel="stylesheet" href="<?php echo $ayarlar["strURL"]; ?>/assets/vendors/jquery-magnific-popup/jquery.magnific-popup.css">
    <link rel="stylesheet" href="<?php echo $ayarlar["strURL"]; ?>/assets/vendors/nouislider/nouislider.min.css">
    <link rel="stylesheet" href="<?php echo $ayarlar["strURL"]; ?>/assets/vendors/nouislider/nouislider.pips.css">
    <link rel="stylesheet" href="<?php echo $ayarlar["strURL"]; ?>/assets/vendors/odometer/odometer.min.css">
    <link rel="stylesheet" href="<?php echo $ayarlar["strURL"]; ?>/assets/vendors/swiper/swiper.min.css">
    <link rel="stylesheet" href="<?php echo $ayarlar["strURL"]; ?>/assets/vendors/icomoon-icons/style.css">
    <link rel="stylesheet" href="<?php echo $ayarlar["strURL"]; ?>/assets/vendors/tiny-slider/tiny-slider.min.css">
    <link rel="stylesheet" href="<?php echo $ayarlar["strURL"]; ?>/assets/vendors/reey-font/stylesheet.css">
    <link rel="stylesheet" href="<?php echo $ayarlar["strURL"]; ?>/assets/vendors/owl-carousel/owl.carousel.min.css">
    <link rel="stylesheet" href="<?php echo $ayarlar["strURL"]; ?>/assets/vendors/owl-carousel/owl.theme.default.min.css">
    <link rel="stylesheet" href="<?php echo $ayarlar["strURL"]; ?>/assets/vendors/twentytwenty/twentytwenty.css">
    <link rel="stylesheet" href="<?php echo $ayarlar["strURL"]; ?>/assets/css/conbiz.css">
    <link rel="stylesheet" href="<?php echo $ayarlar["strURL"]; ?>/assets/css/conbiz-responsive.css">
	<link rel="stylesheet" href="<?php echo $ayarlar["strURL"]; ?>/assets/vendors/bootstrap-select/css/bootstrap-select.min.css" />
